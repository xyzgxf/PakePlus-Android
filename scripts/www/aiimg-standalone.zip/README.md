# AI 生图工作台 - 独立运行版

## 目录说明

```
aiimg-app/           # 构建后的静态站点（可直接部署/打包）
  index.html         # 入口 HTML
  assets/
    index-*.js       # 主 JS（约 410KB，gzip 126KB）
    index-*.css      # 样式（约 44KB，gzip 9KB）
  favicon.svg        # 图标
  icons.svg          # 图标集
```

## 运行方式

### 方式一：本地静态服务（推荐）
```bash
# 进入 aiimg-app 目录
cd aiimg-app

# 起一个本地 http 服务
npx serve .
# 或
python3 -m http.server 8080
```

### 方式二：file:// 直接打开
直接双击 `index.html` 也可以运行（使用 HashRouter，无需服务端路由支持）。
> 注意：部分浏览器对 `file://` 下的 localStorage 有限制，建议用本地 http 服务。

### 方式三：打包成 EXE / APK
- **EXE (Electron/Tauri 等)**：把 `aiimg-app/` 作为 web 静态资源目录加载即可
- **APK (Android WebView / Capacitor 等)**：把 `aiimg-app/` 作为 WebView 的静态资源加载
- **Capacitor** 快速上手：
  ```bash
  npm i -D @capacitor/core @capacitor/cli @capacitor/android
  npx cap init AI 生图 com.aiimg.app --web-dir=aiimg-app
  npx cap add android
  npx cap sync
  npx cap open android
  ```

## 功能清单

- 自由生图（文生图 / 图生图）
- 7 个快捷功能（一键写真 / 头像 / 海报 / 产品图 / 表情包 / 线稿上色 / 老照片修复）
- 抠图（白底图模式，基于 API 图生图）
- 作品图库（搜索 / 查看 / 下载 / 删除）
- 任务记录（状态 / 重试 / 删除）
- API 配置（自定义 Base URL / API Key / Model + 连接测试）

## 存储说明

所有数据存储在浏览器 localStorage 中，key 前缀为 `aiimg_`：
- `aiimg_aiimg_api_config` — API 配置
- `aiimg_aiimg_gallery` — 作品图库
- `aiimg_aiimg_tasks` — 任务记录

## 平台依赖移除说明

原妙搭平台版本依赖 `@lark-apaas/client-toolkit-lite`，独立版已替换为本地垫片：
- `scopedStorage` → `localStorage`（key 前缀 `aiimg_`）
- `logger` → `console`
- `AppContainer` → 透传 React Fragment
- `ErrorRender` → 简易错误页面
- 路由：`BrowserRouter` → `HashRouter`（支持 file:// 和 WebView）
- basePath：移除，使用相对路径 `./`

## 源码参考

- 入口：`src/index-standalone.tsx`
- 垫片：`src/lib/standalone-shim/index.tsx`
- 独立样式：`src/index-standalone.css`
- 构建配置：`vite.config.standalone.ts`
- 构建命令：`npx vite build --config vite.config.standalone.ts`
